import sqlite3
import datetime
from prettytable import PrettyTable

# Database initialization
conn = sqlite3.connect('library_management.db')
cursor = conn.cursor()

# Create tables if they don't exist
cursor.execute('''
    CREATE TABLE IF NOT EXISTS books (
        book_id INTEGER PRIMARY KEY,
        title TEXT,
        author TEXT,
        quantity INTEGER
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS members (
        member_id INTEGER PRIMARY KEY,
        name TEXT,
        contact_number TEXT
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS transactions (
        transaction_id INTEGER PRIMARY KEY,
        book_id INTEGER,
        member_id INTEGER,
        borrow_date TEXT,
        return_date TEXT,
        FOREIGN KEY (book_id) REFERENCES books(book_id),
        FOREIGN KEY (member_id) REFERENCES members(member_id)
    )
''')

conn.commit()

def display_books():
    cursor.execute('SELECT * FROM books')
    books = cursor.fetchall()
    if not books:
        print("No books available.")
    else:
        print("\nBooks Available:")
        hea = ["ID", "TITLE", "AUTHOR","QUANTITY"]
        tab = PrettyTable(hea)
        tab.add_rows(books[0:])
        print(tab)

def display_members():
    cursor.execute('SELECT * FROM members')
    members = cursor.fetchall()
    if not members:
        print("No members available.")
    else:
        print("\nMembers:")
        hea=["ID","NAME","CONTACT NUMBER"]
        tab = PrettyTable(hea)
        tab.add_rows(members[0:])
        print(tab)

def display_transactions():
    cursor.execute('SELECT * FROM transactions')
    transactions = cursor.fetchall()
    if not transactions:
        print("No transactions available.")
    else:
        print("\nTransaction Details:")
        hea=["ID","BOOK ID","MEMBER ID","BORROW DATE","RETURN DATE"]
        tab = PrettyTable(hea)
        tab.add_rows(transactions[0:])
        print(tab)
def add_book():
    title = input("Enter book title: ")
    author = input("Enter author: ")
    quantity = int(input("Enter quantity: "))
    cursor.execute("INSERT INTO books (title, author, quantity) VALUES (?, ?, ?)", (title, author, quantity))
    conn.commit()
    print("Book added successfully.")

def add_member():
    name = input("Enter member name: ")
    contact_number = input("Enter contact number: ")
    cursor.execute("INSERT INTO members (name, contact_number) VALUES (?, ?)", (name, contact_number))
    conn.commit()
    print("Member added successfully.")

def search_book(title):
    cursor.execute("SELECT * FROM books WHERE title LIKE ?", ('%' + title + '%',))
    books = cursor.fetchall()
    if not books:
        print("No matching books found.")
    else:
        print("\nMatching Books:")
        print("ID\tTitle\t\tAuthor\t\tQuantity")
        for book in books:
            print(f"{book[0]}\t{book[1]}\t\t{book[2]}\t\t{book[3]}")

def delete_book(book_id):
    cursor.execute("DELETE FROM books WHERE book_id=?", (book_id,))
    conn.commit()
    print("Book deleted successfully.")

def update_quantity(book_id, new_quantity):
    cursor.execute("UPDATE books SET quantity=? WHERE book_id=?", (new_quantity, book_id))
    conn.commit()
    print("Quantity updated successfully.")

def make_transaction(book_id, member_id, return_date):
    borrow_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute("INSERT INTO transactions (book_id, member_id, borrow_date, return_date) VALUES (?, ?, ?, ?)",
                   (book_id, member_id, borrow_date, return_date))
    cursor.execute("UPDATE books SET quantity = quantity - 1 WHERE book_id = ?", (book_id,))
    conn.commit()
    print("Transaction recorded successfully.")

def main():
    while True:
        print("\nLibrary Management System")
        print("1. Display Books")
        print("2. Display Members")
        print("3. Display Transactions")
        print("4. Add Book")
        print("5. Add Member")
        print("6. Search Book")
        print("7. Delete Book")
        print("8. Update Quantity")
        print("9. Make Transaction")
        print("10. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            display_books()
        elif choice == '2':
            display_members()
        elif choice == '3':
            display_transactions()
        elif choice == '4':
            add_book()
        elif choice == '5':
            add_member()
        elif choice == '6':
            title = input("Enter book title to search: ")
            search_book(title)
        elif choice == '7':
            book_id = input("Enter book ID to delete: ")
            delete_book(book_id)
        elif choice == '8':
            book_id = input("Enter book ID to update quantity: ")
            new_quantity = int(input("Enter new quantity: "))
            update_quantity(book_id, new_quantity)
        elif choice == '9':
            book_id = input("Enter book ID for the transaction: ")
            member_id = input("Enter member ID for the transaction: ")
            return_date = input("Enter return date (YYYY-MM-DD HH:MM:SS): ")
            make_transaction(book_id, member_id, return_date)
        elif choice == '10':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please enter a valid option.")

if __name__ == "__main__":
    main()
